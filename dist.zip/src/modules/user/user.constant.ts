export const USER_TYPE = {
    user: 'user',
    agent: 'agent',
    admin: 'admin'
  } as const;
  